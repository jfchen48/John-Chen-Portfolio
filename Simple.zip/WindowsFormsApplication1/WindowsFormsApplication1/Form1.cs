﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApplication1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            int value;
            if (!int.TryParse(txtOne.Text, out value) || !int.TryParse(txtTwo.Text, out value))
            { 
                MessageBox.Show("Numbers only please");
            }
            else
            {
                int numOne = int.Parse(txtOne.Text);
                int numTow = int.Parse(txtTwo.Text);

                int sum = numOne + numTow;

                label1.Text = sum.ToString();
                
            }
        }

        private void txtOne_TextChanged(object sender, EventArgs e)
        {
            label1.Text = "";
        }

        private void txtTwo_TextChanged(object sender, EventArgs e)
        {
            label1.Text = "";

        }
    }
}
