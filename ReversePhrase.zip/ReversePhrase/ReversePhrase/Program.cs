﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ReversePhrase
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Please enter a sentence to get characters reversed: ");
            var sentence = Console.ReadLine();

            string[] sentArray = sentence.Split(' ');
            string newSentence = "";
            for (int i = 0; i < sentArray.Length; i++)
            {
                char[] wordArray = sentArray[i].ToCharArray();
                Array.Reverse(wordArray);
                string newWord = new string(wordArray);
                newSentence += newWord + " ";    
            }
            Console.WriteLine(newSentence);
            Console.ReadLine();
        }
    }
}
