﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace ConsoleApplication7
{

    public class Items
    {
        private string name;
        private double price;
        private double tax;
        private double importFee;
            
        public Items (string n, double p, bool e, bool i)
        {
            name = n;
            price = p;
            tax = setTax(e);
            importFee = setImport(i);
        }
       
        //true = no tax, false = Tax
        public double setTax(bool e)
        {
            if (e)
            {
                tax = 0;
            }
            else
            {
                tax = price * .1;
            }
            return Math.Round(tax, 2);
        }

        //false = not imported, true = imported
        public double setImport(bool i)
        {
            if (i)
            {
                importFee = price * .05;
            }
            else
            {
                importFee = 0;               
            }
            return Math.Round(importFee, 2);
        }

        public String totalTax()
        {
            string totTax = (importFee + tax).ToString();
            return totTax;
        }

        public String itemInfo()
        {
            String result;
            result = (price + tax + importFee).ToString();
            return result;
        }
        public String itemName()
        {
            String prodName;
            prodName = name + ": ";
            return prodName;
        }
     
    }

     class Program
    {
        static void Main(string[] args)
        {
            
            List<Items> order1 = new List<Items>();
            double orderTax1 = 0;
            double orderTotal1 = 0;
            order1.Add(new Items("1 Book", 12.49, true, false));
            order1.Add(new Items("1 Music CD", 14.99, false, false));
            order1.Add(new Items("1 Chocolate bar", 0.85, true, false));
            Console.WriteLine("Your first order consists of: ");
            foreach (var order in order1)
            {
                Console.WriteLine(order.itemName() + ": " + order.itemInfo());
                orderTax1 += double.Parse(order.totalTax());
                orderTotal1 += double.Parse(order.itemInfo());
            }
            Console.WriteLine("Sales Tax: " + orderTax1 + "\n");
            Console.WriteLine("Total: " + orderTotal1 + "\n");


            List<Items> order2 = new List<Items>();
            double orderTax2 = 0;
            double orderTotal2 = 0;
            order2.Add(new Items("1 Imported Box of Chocolate", 10.00, true, true));
            order2.Add(new Items("1 Imported bottle of perfume", 47.50, false, true));          
            Console.WriteLine("Your second order consists of: ");
            foreach (var order in order2)
            {
                Console.WriteLine(order.itemName() + ": " + order.itemInfo());
                orderTax2 += double.Parse(order.totalTax());
                orderTotal2 += double.Parse(order.itemInfo());

            }
            Console.WriteLine("Sales Tax: " + orderTax2 + "\n");
            Console.WriteLine("Total: " + orderTotal2 + "\n");


            List<Items> order3 = new List<Items>();
            double orderTax3 = 0;
            double orderTotal3 = 0;
            order3.Add(new Items("1 Imported bottle of perfume", 27.99, false, true));
            order3.Add(new Items("1 bottle of perfume", 18.99, false, false));
            order3.Add(new Items("1 packet of headache pills", 9.75, true, false));
            order3.Add(new Items("1 Imported Box of Chocolate", 11.25, true, true));
            Console.WriteLine("Your third order consists of: ");
            foreach (var order in order3)
            {
                Console.WriteLine(order.itemName() + ": " + order.itemInfo());
                orderTax3 += double.Parse(order.totalTax());
                orderTotal3 += double.Parse(order.itemInfo());
            }
            Console.WriteLine("Sales Tax: " + orderTax3 + "\n");
            Console.WriteLine("Total: " + orderTotal3 + "\n");


            Console.ReadLine(); 
        }
    }
}
