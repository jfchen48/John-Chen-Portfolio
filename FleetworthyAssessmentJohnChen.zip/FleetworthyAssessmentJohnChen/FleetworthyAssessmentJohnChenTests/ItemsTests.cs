﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using FleetworthyAssessmentJohnChen;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FleetworthyAssessmentJohnChen.Tests
{
    [TestClass()]
    public class ItemsTests
    {
        [TestMethod()]
        public void ItemsTest()
        {
            Assert.Fail();
        }

        [TestMethod()]
        public void setTaxTest()
        {
            Assert.Fail();
        }

        [TestMethod()]
        public void setImportTest()
        {
            Assert.Fail();
        }

        [TestMethod()]
        public void totalTaxTest()
        {
            Assert.Fail();
        }

        [TestMethod()]
        public void itemInfoTest()
        {
            Assert.Fail();
        }

        [TestMethod()]
        public void itemNameTest()
        {
            Assert.Fail();
        }
    }
}